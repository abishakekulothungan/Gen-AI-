import torch


# Setup target device
DEVICE = "cpu"

if torch.cuda.is_available():
    DEVICE = "cuda"
if torch.backends.mps.is_available():
    DEVICE = "mps"
print(f"Using DEVICE: {DEVICE}")

def train_step(model,
               train_dataloader,
               loss_fn,
               optimizer):
    model.train()
    train_accuracy, train_loss = 0, 0
    for batch, (train_x, train_y) in enumerate(train_dataloader):
        train_x, train_y = train_x.to(DEVICE), train_y.to(DEVICE)

        train_preds = model(train_x)
        y_pred_class = torch.argmax(torch.softmax(train_preds, dim=1), dim=1)
        train_accuracy += (y_pred_class == train_y).sum().item()

        loss = loss_fn(train_preds, train_y)
        train_loss += loss

        optimizer.zero_grad()

        loss.backward()

        optimizer.step()

        if batch % 700 == 0:
            print(f"Batch: {batch} | Loss: {train_loss / ((batch + 1) * len(train_x)):.4f} | Accuracy: {train_accuracy / ((batch + 1) * len(train_x)):.4f}")

    train_accuracy /= len(train_dataloader) * 32
    train_loss /= len(train_dataloader) * 32

    return train_accuracy, train_loss

def validation_step(model,
               val_dataloader,
               loss_fn):
    model.eval()

    val_accuracy, val_loss = 0.0, 0.0

    with torch.inference_mode():
        for val_x, val_y in val_dataloader:
            val_x, val_y = val_x.to(DEVICE), val_y.to(DEVICE)

            val_preds = model(val_x)
            val_preds_class = torch.argmax(torch.softmax(val_preds, dim=1), dim=1)
            val_accuracy += (val_preds_class == val_y).type(torch.float).sum().item()
            val_loss += loss_fn(val_preds, val_y)

        val_accuracy /= float(len(val_dataloader) * 32)
        val_loss /= float(len(val_dataloader) * 32)

    return val_accuracy, val_loss


def train(epochs, model, train_dataloader, val_dataloader, loss_fn, optimizer):
    # Create empty results dictionary
    results = {"train_loss": [],
               "train_acc": [],
               "test_loss": [],
               "test_acc": []
               }

    # Make sure model on target device
    model.to(DEVICE)

    for epoch in range(epochs):
        train_acc, train_loss = train_step(model,
                                           train_dataloader,
                                           loss_fn,
                                           optimizer)
        test_acc, test_loss = validation_step(model,
                                        val_dataloader,
                                        loss_fn)

        # Print out what's happening
        print(
            f"Epoch: {epoch + 1} | "
            f"train_loss: {train_loss:.4f} | "
            f"train_acc: {train_acc:.4f} | "
            f"test_loss: {test_loss:.4f} | "
            f"test_acc: {test_acc:.4f}"
        )

        # Update results dictionary
        results["train_loss"].append(train_loss)
        results["train_acc"].append(train_acc)
        results["test_loss"].append(test_loss)
        results["test_acc"].append(test_acc)

    return results

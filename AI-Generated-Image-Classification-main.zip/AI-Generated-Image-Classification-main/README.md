# AI-Generated-Image-Classification
Using PyTorch Vision to build an AI model that classifies and labels AI-generated images with high accuracy

## Data:
- [Image Data from Kaggle 11 GB](https://www.kaggle.com/datasets/alessandrasala79/ai-vs-human-generated-dataset)

## Issues:
- [Traceback (most recent call last):
  File "<string>", line 1, in <module>
  File "/Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/multiprocessing/spawn.py", line 116, in spawn_main
    exitcode = _main(fd, parent_sentinel)
  File "/Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/multiprocessing/spawn.py", line 126, in _main
    self = reduction.pickle.load(from_parent)
AttributeError: Can't get attribute 'CustomImageDataset' on <module '__main__' (built-in)>](https://github.com/Lightning-AI/pytorch-lightning/discussions/15350)
- [Issue with DataLoader Some images in between get shape of (1, 64, 64) instead of (3, 64, 64)](https://discuss.pytorch.org/t/runtimeerror-stack-expects-each-tensor-to-be-equal-size-but-got-3-224-224-at-entry-0-and-3-224-336-at-entry-3/87211/25)
